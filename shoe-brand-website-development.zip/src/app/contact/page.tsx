"use client";

import { useState, type FormEvent } from "react";

export default function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [error, setError] = useState("");

  function update(key: keyof typeof form, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setStatus("loading");
    setError("");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to send message");
      setStatus("done");
      setForm({ name: "", email: "", subject: "", message: "" });
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error ? err.message : "Something went wrong");
    }
  }

  return (
    <main className="mx-auto max-w-5xl px-5 py-14 sm:px-8">
      <div className="text-center">
        <p className="text-xs font-black uppercase tracking-widest text-orange-500">
          Get In Touch
        </p>
        <h1 className="mt-2 text-3xl font-black uppercase tracking-tight sm:text-4xl">
          Contact Let&apos;s Wear
        </h1>
        <p className="mx-auto mt-3 max-w-xl text-slate-600">
          Questions about an order, sizing, or a bulk business inquiry? Send us
          a message and our team will get back to you within 24 hours.
        </p>
      </div>

      <div className="mt-12 grid gap-10 md:grid-cols-5">
        <div className="flex flex-col gap-6 md:col-span-2">
          <div className="rounded-2xl border border-black/10 p-6">
            <p className="text-sm font-black uppercase tracking-wide">Email</p>
            <p className="mt-1 text-slate-600">support@letswear.com</p>
          </div>
          <div className="rounded-2xl border border-black/10 p-6">
            <p className="text-sm font-black uppercase tracking-wide">Phone</p>
            <p className="mt-1 text-slate-600">+1 (800) 555-0134</p>
          </div>
          <div className="rounded-2xl border border-black/10 p-6">
            <p className="text-sm font-black uppercase tracking-wide">Studio</p>
            <p className="mt-1 text-slate-600">
              128 Hustle Ave, Suite 4, Brooklyn, NY 11201
            </p>
          </div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="flex flex-col gap-4 rounded-2xl border border-black/10 p-6 md:col-span-3"
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="flex flex-col gap-1 text-sm font-semibold">
              Name
              <input
                required
                value={form.name}
                onChange={(e) => update("name", e.target.value)}
                className="rounded-xl border border-black/15 px-4 py-2.5 outline-none focus:border-orange-500"
              />
            </label>
            <label className="flex flex-col gap-1 text-sm font-semibold">
              Email
              <input
                required
                type="email"
                value={form.email}
                onChange={(e) => update("email", e.target.value)}
                className="rounded-xl border border-black/15 px-4 py-2.5 outline-none focus:border-orange-500"
              />
            </label>
          </div>
          <label className="flex flex-col gap-1 text-sm font-semibold">
            Subject
            <input
              value={form.subject}
              onChange={(e) => update("subject", e.target.value)}
              className="rounded-xl border border-black/15 px-4 py-2.5 outline-none focus:border-orange-500"
              placeholder="Order inquiry, wholesale, partnership..."
            />
          </label>
          <label className="flex flex-col gap-1 text-sm font-semibold">
            Message
            <textarea
              required
              value={form.message}
              onChange={(e) => update("message", e.target.value)}
              className="min-h-[140px] rounded-xl border border-black/15 px-4 py-2.5 outline-none focus:border-orange-500"
            />
          </label>

          {status === "done" && (
            <p className="rounded-lg bg-green-50 px-4 py-2 text-sm font-semibold text-green-600">
              Message sent! We&apos;ll be in touch soon.
            </p>
          )}
          {status === "error" && (
            <p className="rounded-lg bg-red-50 px-4 py-2 text-sm font-semibold text-red-600">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={status === "loading"}
            className="mt-2 rounded-full bg-black px-6 py-3 text-sm font-black uppercase tracking-wide text-white transition hover:bg-orange-500 disabled:opacity-60"
          >
            {status === "loading" ? "Sending..." : "Send Message"}
          </button>
        </form>
      </div>
    </main>
  );
}
