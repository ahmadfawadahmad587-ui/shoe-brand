import Image from "next/image";
import Link from "next/link";
import { getFeaturedProducts } from "@/lib/data";
import ProductCard from "@/components/ProductCard";

export const dynamic = "force-dynamic";

const CATEGORIES = [
  { label: "Running", value: "running", emoji: "🏃" },
  { label: "Basketball", value: "basketball", emoji: "🏀" },
  { label: "Lifestyle", value: "lifestyle", emoji: "🛹" },
  { label: "Outdoor", value: "outdoor", emoji: "🥾" },
];

export default async function HomePage() {
  const featured = await getFeaturedProducts();

  return (
    <main>
      {/* Hero */}
      <section className="relative overflow-hidden bg-black text-white">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-5 py-16 sm:px-8 md:grid-cols-2 md:py-24">
          <div>
            <p className="mb-4 inline-block rounded-full bg-orange-500 px-4 py-1 text-xs font-black uppercase tracking-widest">
              New Season Drop
            </p>
            <h1 className="text-4xl font-black leading-[1.05] sm:text-5xl md:text-6xl">
              Let&apos;s Wear
              <span className="block text-orange-500">Your Next Step.</span>
            </h1>
            <p className="mt-5 max-w-md text-base text-white/70">
              Premium sneakers engineered for runners, ballers, and everyday
              hustlers. Bold design, real comfort, no compromises.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="/products"
                className="rounded-full bg-orange-500 px-7 py-3 text-sm font-black uppercase tracking-wide transition hover:bg-orange-600"
              >
                Shop Now
              </Link>
              <Link
                href="/about"
                className="rounded-full border border-white/30 px-7 py-3 text-sm font-black uppercase tracking-wide transition hover:bg-white hover:text-black"
              >
                Our Story
              </Link>
            </div>
          </div>
          <div className="relative mx-auto aspect-square w-full max-w-md overflow-hidden rounded-3xl">
            <Image
              src="/images/hero.jpg"
              alt="Featured Let's Wear sneaker"
              fill
              priority
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 480px"
            />
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
        <h2 className="text-2xl font-black uppercase tracking-tight sm:text-3xl">
          Shop by Category
        </h2>
        <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
          {CATEGORIES.map((cat) => (
            <Link
              key={cat.value}
              href={`/products?category=${cat.value}`}
              className="group flex flex-col items-center gap-3 rounded-2xl border border-black/10 bg-slate-50 px-4 py-8 text-center transition hover:border-orange-500 hover:bg-orange-50"
            >
              <span className="text-4xl transition group-hover:scale-110">
                {cat.emoji}
              </span>
              <span className="text-sm font-black uppercase tracking-wide">
                {cat.label}
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured products */}
      <section className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
        <div className="flex items-end justify-between">
          <h2 className="text-2xl font-black uppercase tracking-tight sm:text-3xl">
            Featured Kicks
          </h2>
          <Link
            href="/products"
            className="text-sm font-bold uppercase tracking-wide text-orange-500 hover:underline"
          >
            View All →
          </Link>
        </div>
        <div className="mt-8 grid grid-cols-2 gap-4 sm:gap-6 md:grid-cols-4">
          {featured.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Value props */}
      <section className="bg-slate-950 text-white">
        <div className="mx-auto grid max-w-7xl gap-8 px-5 py-16 sm:px-8 md:grid-cols-3">
          {[
            {
              title: "Free Shipping",
              desc: "On every order over $75, delivered in 3-5 business days.",
              icon: "🚚",
            },
            {
              title: "Easy 30-Day Returns",
              desc: "Didn't fit right? Send it back, no questions asked.",
              icon: "🔁",
            },
            {
              title: "Built to Last",
              desc: "Premium materials, tested by athletes and hustlers alike.",
              icon: "💪",
            },
          ].map((item) => (
            <div key={item.title} className="text-center">
              <div className="text-4xl">{item.icon}</div>
              <h3 className="mt-4 text-lg font-black uppercase">{item.title}</h3>
              <p className="mt-2 text-sm text-white/60">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-5 py-16 text-center sm:px-8">
        <h2 className="text-3xl font-black uppercase tracking-tight sm:text-4xl">
          Ready to step up your game?
        </h2>
        <p className="mx-auto mt-3 max-w-xl text-slate-600">
          Browse the full Let&apos;s Wear collection and find your perfect fit.
        </p>
        <Link
          href="/products"
          className="mt-7 inline-block rounded-full bg-black px-8 py-3 text-sm font-black uppercase tracking-wide text-white transition hover:bg-orange-500"
        >
          Shop the Collection
        </Link>
      </section>
    </main>
  );
}
