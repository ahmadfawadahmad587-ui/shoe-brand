import { getAllProducts, getCategories } from "@/lib/data";
import ProductsGrid from "@/components/ProductsGrid";

export const dynamic = "force-dynamic";

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>;
}) {
  const { category } = await searchParams;
  const [products, categories] = await Promise.all([
    getAllProducts(),
    getCategories(),
  ]);

  return (
    <main className="mx-auto max-w-7xl px-5 py-10 sm:px-8">
      <div className="mb-8">
        <p className="text-xs font-black uppercase tracking-widest text-orange-500">
          Full Collection
        </p>
        <h1 className="mt-2 text-3xl font-black uppercase tracking-tight sm:text-4xl">
          Shop All Shoes
        </h1>
      </div>
      <ProductsGrid
        products={products}
        categories={categories}
        initialCategory={category ?? "all"}
      />
    </main>
  );
}
