import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getProductBySlug, getRelatedProducts } from "@/lib/data";
import { formatPrice } from "@/lib/format";
import AddToCartForm from "@/components/AddToCartForm";
import ProductCard from "@/components/ProductCard";

export const dynamic = "force-dynamic";

export default async function ProductDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const related = await getRelatedProducts(product.category, product.slug);
  const onSale =
    product.compareAtPrice && Number(product.compareAtPrice) > Number(product.price);

  return (
    <main className="mx-auto max-w-7xl px-5 py-10 sm:px-8">
      <nav className="mb-6 text-xs font-semibold text-slate-500">
        <Link href="/" className="hover:text-black">Home</Link>
        <span className="mx-2">/</span>
        <Link href="/products" className="hover:text-black">Shop</Link>
        <span className="mx-2">/</span>
        <span className="text-black">{product.name}</span>
      </nav>

      <div className="grid gap-10 md:grid-cols-2">
        <div className="relative aspect-square overflow-hidden rounded-3xl bg-slate-100">
          <Image
            src={product.imageUrl}
            alt={product.name}
            fill
            priority
            className="object-cover"
            sizes="(max-width: 768px) 100vw, 560px"
          />
        </div>

        <div>
          <p className="text-xs font-black uppercase tracking-widest text-orange-500">
            {product.category}
          </p>
          <h1 className="mt-2 text-3xl font-black uppercase tracking-tight sm:text-4xl">
            {product.name}
          </h1>
          <div className="mt-3 flex items-center gap-3">
            <span className="text-2xl font-black">{formatPrice(product.price)}</span>
            {onSale && (
              <span className="text-base font-semibold text-slate-400 line-through">
                {formatPrice(product.compareAtPrice as string)}
              </span>
            )}
          </div>
          <p className="mt-5 max-w-lg text-sm leading-relaxed text-slate-600">
            {product.description}
          </p>
          {product.colors.length > 0 && (
            <p className="mt-4 text-sm text-slate-500">
              <span className="font-bold text-slate-800">Color: </span>
              {product.colors.join(", ")}
            </p>
          )}

          <AddToCartForm product={product} />
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-16">
          <h2 className="text-2xl font-black uppercase tracking-tight">
            You Might Also Like
          </h2>
          <div className="mt-6 grid grid-cols-2 gap-4 sm:gap-6 md:grid-cols-4">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </main>
  );
}
