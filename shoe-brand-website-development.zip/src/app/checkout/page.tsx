"use client";

import { useState, type FormEvent } from "react";
import Image from "next/image";
import Link from "next/link";
import { useCart } from "@/lib/cart-context";
import { formatPrice } from "@/lib/format";

export default function CheckoutPage() {
  const { items, totalPrice, clearCart } = useCart();
  const [form, setForm] = useState({
    customerName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    notes: "",
  });
  const [status, setStatus] = useState<"idle" | "loading" | "error">("idle");
  const [error, setError] = useState("");
  const [orderId, setOrderId] = useState<number | null>(null);

  const shipping = totalPrice >= 75 || totalPrice === 0 ? 0 : 9.99;
  const grandTotal = totalPrice + shipping;

  function updateField(key: keyof typeof form, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (items.length === 0) return;
    setStatus("loading");
    setError("");
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, items }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to place order");
      setOrderId(data.id);
      clearCart();
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error ? err.message : "Something went wrong");
    }
  }

  if (orderId) {
    return (
      <main className="mx-auto flex max-w-2xl flex-col items-center gap-4 px-5 py-24 text-center">
        <p className="text-6xl">🎉</p>
        <h1 className="text-3xl font-black uppercase">Order Confirmed!</h1>
        <p className="text-slate-600">
          Thanks for your order, <span className="font-bold">#{orderId}</span>.
          We&apos;ll email you a confirmation shortly and get your kicks shipped
          out fast.
        </p>
        <Link
          href="/products"
          className="mt-4 rounded-full bg-black px-7 py-3 text-sm font-black uppercase tracking-wide text-white transition hover:bg-orange-500"
        >
          Keep Shopping
        </Link>
      </main>
    );
  }

  if (items.length === 0) {
    return (
      <main className="mx-auto flex max-w-2xl flex-col items-center gap-4 px-5 py-24 text-center">
        <p className="text-6xl">🛒</p>
        <h1 className="text-2xl font-black uppercase">Nothing to check out</h1>
        <p className="text-slate-500">Add some shoes to your bag first.</p>
        <Link
          href="/products"
          className="mt-3 rounded-full bg-black px-7 py-3 text-sm font-black uppercase tracking-wide text-white transition hover:bg-orange-500"
        >
          Shop Now
        </Link>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-5xl px-5 py-10 sm:px-8">
      <h1 className="text-3xl font-black uppercase tracking-tight">Checkout</h1>

      <div className="mt-8 grid gap-10 md:grid-cols-3">
        <form onSubmit={handleSubmit} className="flex flex-col gap-4 md:col-span-2">
          <h2 className="text-lg font-black uppercase">Shipping Details</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="flex flex-col gap-1 text-sm font-semibold">
              Full Name
              <input
                required
                value={form.customerName}
                onChange={(e) => updateField("customerName", e.target.value)}
                className="rounded-xl border border-black/15 px-4 py-2.5 outline-none focus:border-orange-500"
                placeholder="Jane Doe"
              />
            </label>
            <label className="flex flex-col gap-1 text-sm font-semibold">
              Email
              <input
                required
                type="email"
                value={form.email}
                onChange={(e) => updateField("email", e.target.value)}
                className="rounded-xl border border-black/15 px-4 py-2.5 outline-none focus:border-orange-500"
                placeholder="jane@email.com"
              />
            </label>
            <label className="flex flex-col gap-1 text-sm font-semibold">
              Phone
              <input
                required
                value={form.phone}
                onChange={(e) => updateField("phone", e.target.value)}
                className="rounded-xl border border-black/15 px-4 py-2.5 outline-none focus:border-orange-500"
                placeholder="+1 555 123 4567"
              />
            </label>
            <label className="flex flex-col gap-1 text-sm font-semibold">
              City
              <input
                required
                value={form.city}
                onChange={(e) => updateField("city", e.target.value)}
                className="rounded-xl border border-black/15 px-4 py-2.5 outline-none focus:border-orange-500"
                placeholder="New York"
              />
            </label>
          </div>
          <label className="flex flex-col gap-1 text-sm font-semibold">
            Shipping Address
            <textarea
              required
              value={form.address}
              onChange={(e) => updateField("address", e.target.value)}
              className="min-h-[80px] rounded-xl border border-black/15 px-4 py-2.5 outline-none focus:border-orange-500"
              placeholder="Street, apartment, zip code..."
            />
          </label>
          <label className="flex flex-col gap-1 text-sm font-semibold">
            Order Notes (optional)
            <textarea
              value={form.notes}
              onChange={(e) => updateField("notes", e.target.value)}
              className="min-h-[60px] rounded-xl border border-black/15 px-4 py-2.5 outline-none focus:border-orange-500"
              placeholder="Delivery instructions..."
            />
          </label>

          {error && (
            <p className="rounded-lg bg-red-50 px-4 py-2 text-sm font-semibold text-red-600">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={status === "loading"}
            className="mt-2 w-full rounded-full bg-orange-500 px-6 py-3 text-sm font-black uppercase tracking-wide text-white transition hover:bg-orange-600 disabled:opacity-60"
          >
            {status === "loading" ? "Placing Order..." : `Place Order — ${formatPrice(grandTotal)}`}
          </button>
          <p className="text-center text-xs text-slate-400">
            Cash on delivery / bank transfer details will be sent by email.
          </p>
        </form>

        <div className="h-fit rounded-2xl border border-black/10 p-6">
          <h2 className="text-lg font-black uppercase">Order Summary</h2>
          <ul className="mt-4 flex flex-col gap-3">
            {items.map((item) => (
              <li key={`${item.productId}-${item.size}`} className="flex gap-3">
                <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-slate-100">
                  <Image
                    src={item.imageUrl}
                    alt={item.name}
                    fill
                    className="object-cover"
                    sizes="56px"
                  />
                </div>
                <div className="flex flex-1 justify-between text-sm">
                  <div>
                    <p className="font-bold">{item.name}</p>
                    <p className="text-slate-500">
                      Size {item.size} × {item.quantity}
                    </p>
                  </div>
                  <p className="font-bold">
                    {formatPrice(Number(item.price) * item.quantity)}
                  </p>
                </div>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex justify-between border-t border-black/10 pt-4 text-sm text-slate-600">
            <span>Subtotal</span>
            <span>{formatPrice(totalPrice)}</span>
          </div>
          <div className="mt-1 flex justify-between text-sm text-slate-600">
            <span>Shipping</span>
            <span>{shipping === 0 ? "Free" : formatPrice(shipping)}</span>
          </div>
          <div className="mt-3 flex justify-between border-t border-black/10 pt-3 text-base font-black">
            <span>Total</span>
            <span>{formatPrice(grandTotal)}</span>
          </div>
        </div>
      </div>
    </main>
  );
}
