import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { isAdminRequest } from "@/lib/admin";

export async function GET(req: NextRequest) {
  const category = req.nextUrl.searchParams.get("category");
  const { getAllProducts } = await import("@/lib/data");
  const list = await getAllProducts(category ?? undefined);
  return NextResponse.json(list);
}

export async function POST(req: NextRequest) {
  if (!isAdminRequest(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();
  const {
    name,
    slug,
    description,
    price,
    compareAtPrice,
    category,
    imageUrl,
    sizes,
    colors,
    stock,
    featured,
    isNew,
  } = body;

  if (!name || !slug || !description || !price || !category || !imageUrl) {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
  }

  try {
    const [created] = await db
      .insert(products)
      .values({
        name,
        slug,
        description,
        price: String(price),
        compareAtPrice: compareAtPrice ? String(compareAtPrice) : null,
        category,
        imageUrl,
        sizes: Array.isArray(sizes) ? sizes : [],
        colors: Array.isArray(colors) ? colors : [],
        stock: Number(stock) || 0,
        featured: Boolean(featured),
        isNew: Boolean(isNew),
      })
      .returning();
    return NextResponse.json(created, { status: 201 });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to create product";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
