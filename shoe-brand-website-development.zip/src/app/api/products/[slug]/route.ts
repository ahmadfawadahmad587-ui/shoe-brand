import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";
import { isAdminRequest } from "@/lib/admin";
import { getProductBySlug } from "@/lib/data";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ slug: string }> },
) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(product);
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> },
) {
  if (!isAdminRequest(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { slug } = await params;
  const body = await req.json();

  const updateData: Record<string, unknown> = {};
  const fields = [
    "name",
    "description",
    "category",
    "imageUrl",
    "sizes",
    "colors",
    "stock",
    "featured",
    "isNew",
  ] as const;
  for (const field of fields) {
    if (field in body) updateData[field] = body[field];
  }
  if ("price" in body) updateData.price = String(body.price);
  if ("compareAtPrice" in body) {
    updateData.compareAtPrice = body.compareAtPrice ? String(body.compareAtPrice) : null;
  }
  if ("stock" in body) updateData.stock = Number(body.stock);

  try {
    const [updated] = await db
      .update(products)
      .set(updateData)
      .where(eq(products.slug, slug))
      .returning();
    if (!updated) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json(updated);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to update";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> },
) {
  if (!isAdminRequest(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { slug } = await params;
  await db.delete(products).where(eq(products.slug, slug));
  return NextResponse.json({ ok: true });
}
