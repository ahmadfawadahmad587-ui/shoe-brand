import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders, products } from "@/db/schema";
import { eq, sql, desc } from "drizzle-orm";
import { isAdminRequest } from "@/lib/admin";
import type { OrderItem } from "@/db/schema";

export async function GET(req: NextRequest) {
  if (!isAdminRequest(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const rows = await db.select().from(orders).orderBy(desc(orders.createdAt));
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { customerName, email, phone, address, city, notes, items } = body;

  if (!customerName || !email || !phone || !address || !city) {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
  }

  if (!Array.isArray(items) || items.length === 0) {
    return NextResponse.json({ error: "Cart is empty" }, { status: 400 });
  }

  const orderItems: OrderItem[] = items.map(
    (item: {
      productId: number;
      name: string;
      slug: string;
      imageUrl: string;
      size: string;
      quantity: number;
      price: string;
    }) => ({
      productId: item.productId,
      name: item.name,
      slug: item.slug,
      imageUrl: item.imageUrl,
      size: item.size,
      quantity: item.quantity,
      price: item.price,
    }),
  );

  const total = orderItems.reduce(
    (sum, item) => sum + Number(item.price) * item.quantity,
    0,
  );

  try {
    const [created] = await db
      .insert(orders)
      .values({
        customerName,
        email,
        phone,
        address,
        city,
        notes: notes ?? null,
        items: orderItems,
        total: total.toFixed(2),
        status: "pending",
      })
      .returning();

    for (const item of orderItems) {
      await db
        .update(products)
        .set({ stock: sql`GREATEST(${products.stock} - ${item.quantity}, 0)` })
        .where(eq(products.id, item.productId));
    }

    return NextResponse.json(created, { status: 201 });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to place order";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
