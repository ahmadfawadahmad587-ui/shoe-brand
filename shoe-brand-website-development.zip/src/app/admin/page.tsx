"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { formatPrice } from "@/lib/format";
import type { Product } from "@/lib/types";

const STORAGE_KEY = "letswear-admin-key";

type OrderItem = {
  productId: number;
  name: string;
  slug: string;
  imageUrl: string;
  size: string;
  quantity: number;
  price: string;
};

type Order = {
  id: number;
  customerName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  notes: string | null;
  items: OrderItem[];
  total: string;
  status: string;
  createdAt: string;
};

type Message = {
  id: number;
  name: string;
  email: string;
  subject: string;
  message: string;
  createdAt: string;
};

const EMPTY_PRODUCT = {
  name: "",
  slug: "",
  description: "",
  price: "",
  compareAtPrice: "",
  category: "",
  imageUrl: "",
  sizes: "6,7,8,9,10,11",
  colors: "Black",
  stock: "20",
  featured: false,
  isNew: false,
};

export default function AdminPage() {
  const [key, setKey] = useState("");
  const [authed, setAuthed] = useState(false);
  const [checking, setChecking] = useState(true);
  const [tab, setTab] = useState<"products" | "orders" | "messages">("products");

  useEffect(() => {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved) {
      setKey(saved);
      setAuthed(true);
    }
    setChecking(false);
  }, []);

  function login(e: React.FormEvent) {
    e.preventDefault();
    window.localStorage.setItem(STORAGE_KEY, key);
    setAuthed(true);
  }

  function logout() {
    window.localStorage.removeItem(STORAGE_KEY);
    setKey("");
    setAuthed(false);
  }

  if (checking) return null;

  if (!authed) {
    return (
      <main className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-5 py-14">
        <h1 className="text-2xl font-black uppercase">Admin Access</h1>
        <p className="mt-2 text-sm text-slate-500">
          Enter your admin key to manage products, orders, and messages.
        </p>
        <form onSubmit={login} className="mt-6 flex flex-col gap-3">
          <input
            type="password"
            required
            value={key}
            onChange={(e) => setKey(e.target.value)}
            placeholder="Admin key"
            className="rounded-xl border border-black/15 px-4 py-3 outline-none focus:border-orange-500"
          />
          <button
            type="submit"
            className="rounded-full bg-black px-6 py-3 text-sm font-black uppercase tracking-wide text-white hover:bg-orange-500"
          >
            Enter Dashboard
          </button>
        </form>
        <p className="mt-4 text-xs text-slate-400">
          Default key is <code className="font-mono">letswear-admin-2024</code>{" "}
          unless the <code className="font-mono">ADMIN_SECRET_KEY</code>{" "}
          environment variable has been set.
        </p>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-7xl px-5 py-10 sm:px-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-3xl font-black uppercase tracking-tight">
          Admin Dashboard
        </h1>
        <button
          type="button"
          onClick={logout}
          className="rounded-full border border-black/15 px-4 py-2 text-xs font-bold uppercase tracking-wide hover:bg-slate-100"
        >
          Log Out
        </button>
      </div>

      <div className="mt-6 flex gap-2 border-b border-black/10">
        {(["products", "orders", "messages"] as const).map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTab(t)}
            className={`px-4 py-3 text-sm font-black uppercase tracking-wide ${
              tab === t
                ? "border-b-2 border-orange-500 text-black"
                : "text-slate-400 hover:text-black"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="mt-8">
        {tab === "products" && <ProductsAdmin adminKey={key} onUnauthorized={logout} />}
        {tab === "orders" && <OrdersAdmin adminKey={key} onUnauthorized={logout} />}
        {tab === "messages" && <MessagesAdmin adminKey={key} onUnauthorized={logout} />}
      </div>
    </main>
  );
}

function ProductsAdmin({
  adminKey,
  onUnauthorized,
}: {
  adminKey: string;
  onUnauthorized: () => void;
}) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ ...EMPTY_PRODUCT });
  const [editingSlug, setEditingSlug] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const res = await fetch("/api/products");
    const data = await res.json();
    setProducts(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function resetForm() {
    setForm({ ...EMPTY_PRODUCT });
    setEditingSlug(null);
  }

  function startEdit(p: Product) {
    setEditingSlug(p.slug);
    setForm({
      name: p.name,
      slug: p.slug,
      description: p.description,
      price: p.price,
      compareAtPrice: p.compareAtPrice ?? "",
      category: p.category,
      imageUrl: p.imageUrl,
      sizes: p.sizes.join(","),
      colors: p.colors.join(","),
      stock: String(p.stock),
      featured: p.featured,
      isNew: p.isNew,
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const payload = {
      name: form.name,
      slug: form.slug || form.name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
      description: form.description,
      price: form.price,
      compareAtPrice: form.compareAtPrice || null,
      category: form.category,
      imageUrl: form.imageUrl,
      sizes: form.sizes.split(",").map((s) => s.trim()).filter(Boolean),
      colors: form.colors.split(",").map((s) => s.trim()).filter(Boolean),
      stock: Number(form.stock),
      featured: form.featured,
      isNew: form.isNew,
    };

    try {
      const res = editingSlug
        ? await fetch(`/api/products/${editingSlug}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json", "x-admin-key": adminKey },
            body: JSON.stringify(payload),
          })
        : await fetch("/api/products", {
            method: "POST",
            headers: { "Content-Type": "application/json", "x-admin-key": adminKey },
            body: JSON.stringify(payload),
          });

      if (res.status === 401) {
        onUnauthorized();
        return;
      }
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to save product");
      resetForm();
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(slug: string) {
    if (!confirm("Delete this product?")) return;
    const res = await fetch(`/api/products/${slug}`, {
      method: "DELETE",
      headers: { "x-admin-key": adminKey },
    });
    if (res.status === 401) {
      onUnauthorized();
      return;
    }
    load();
  }

  return (
    <div className="grid gap-10 lg:grid-cols-5">
      <form
        onSubmit={handleSubmit}
        className="flex flex-col gap-3 rounded-2xl border border-black/10 p-6 lg:col-span-2"
      >
        <h2 className="text-lg font-black uppercase">
          {editingSlug ? `Edit: ${editingSlug}` : "Add New Product"}
        </h2>
        <input
          required
          placeholder="Name"
          value={form.name}
          onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
          className="rounded-xl border border-black/15 px-4 py-2.5 text-sm outline-none focus:border-orange-500"
        />
        <input
          placeholder="Slug (auto-generated if blank)"
          value={form.slug}
          onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))}
          className="rounded-xl border border-black/15 px-4 py-2.5 text-sm outline-none focus:border-orange-500"
        />
        <textarea
          required
          placeholder="Description"
          value={form.description}
          onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
          className="min-h-[80px] rounded-xl border border-black/15 px-4 py-2.5 text-sm outline-none focus:border-orange-500"
        />
        <div className="grid grid-cols-2 gap-3">
          <input
            required
            placeholder="Price"
            value={form.price}
            onChange={(e) => setForm((f) => ({ ...f, price: e.target.value }))}
            className="rounded-xl border border-black/15 px-4 py-2.5 text-sm outline-none focus:border-orange-500"
          />
          <input
            placeholder="Compare-at price"
            value={form.compareAtPrice}
            onChange={(e) => setForm((f) => ({ ...f, compareAtPrice: e.target.value }))}
            className="rounded-xl border border-black/15 px-4 py-2.5 text-sm outline-none focus:border-orange-500"
          />
        </div>
        <input
          required
          placeholder="Category (running, lifestyle, basketball, outdoor, casual)"
          value={form.category}
          onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
          className="rounded-xl border border-black/15 px-4 py-2.5 text-sm outline-none focus:border-orange-500"
        />
        <input
          required
          placeholder="Image URL (e.g. /images/products/my-shoe.jpg)"
          value={form.imageUrl}
          onChange={(e) => setForm((f) => ({ ...f, imageUrl: e.target.value }))}
          className="rounded-xl border border-black/15 px-4 py-2.5 text-sm outline-none focus:border-orange-500"
        />
        <input
          placeholder="Sizes, comma separated (6,7,8,9,10)"
          value={form.sizes}
          onChange={(e) => setForm((f) => ({ ...f, sizes: e.target.value }))}
          className="rounded-xl border border-black/15 px-4 py-2.5 text-sm outline-none focus:border-orange-500"
        />
        <input
          placeholder="Colors, comma separated"
          value={form.colors}
          onChange={(e) => setForm((f) => ({ ...f, colors: e.target.value }))}
          className="rounded-xl border border-black/15 px-4 py-2.5 text-sm outline-none focus:border-orange-500"
        />
        <input
          required
          type="number"
          placeholder="Stock"
          value={form.stock}
          onChange={(e) => setForm((f) => ({ ...f, stock: e.target.value }))}
          className="rounded-xl border border-black/15 px-4 py-2.5 text-sm outline-none focus:border-orange-500"
        />
        <div className="flex gap-4 text-sm font-semibold">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={form.featured}
              onChange={(e) => setForm((f) => ({ ...f, featured: e.target.checked }))}
            />
            Featured
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={form.isNew}
              onChange={(e) => setForm((f) => ({ ...f, isNew: e.target.checked }))}
            />
            New Arrival
          </label>
        </div>

        {error && <p className="text-sm font-semibold text-red-500">{error}</p>}

        <div className="mt-2 flex gap-3">
          <button
            type="submit"
            disabled={saving}
            className="flex-1 rounded-full bg-orange-500 px-5 py-2.5 text-sm font-black uppercase tracking-wide text-white hover:bg-orange-600 disabled:opacity-60"
          >
            {saving ? "Saving..." : editingSlug ? "Update Product" : "Add Product"}
          </button>
          {editingSlug && (
            <button
              type="button"
              onClick={resetForm}
              className="rounded-full border border-black/15 px-5 py-2.5 text-sm font-bold uppercase tracking-wide hover:bg-slate-100"
            >
              Cancel
            </button>
          )}
        </div>
      </form>

      <div className="lg:col-span-3">
        {loading ? (
          <p className="text-slate-500">Loading products...</p>
        ) : (
          <div className="flex flex-col gap-3">
            {products.map((p) => (
              <div
                key={p.id}
                className="flex items-center gap-4 rounded-2xl border border-black/10 p-3"
              >
                <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-slate-100">
                  <Image src={p.imageUrl} alt={p.name} fill className="object-cover" sizes="64px" />
                </div>
                <div className="flex-1">
                  <p className="font-bold">{p.name}</p>
                  <p className="text-xs text-slate-500">
                    {p.category} • {formatPrice(p.price)} • Stock: {p.stock}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => startEdit(p)}
                  className="rounded-full border border-black/15 px-3 py-1.5 text-xs font-bold hover:bg-slate-100"
                >
                  Edit
                </button>
                <button
                  type="button"
                  onClick={() => handleDelete(p.slug)}
                  className="rounded-full border border-red-200 px-3 py-1.5 text-xs font-bold text-red-500 hover:bg-red-50"
                >
                  Delete
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function OrdersAdmin({
  adminKey,
  onUnauthorized,
}: {
  adminKey: string;
  onUnauthorized: () => void;
}) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const res = await fetch("/api/orders", { headers: { "x-admin-key": adminKey } });
    if (res.status === 401) {
      onUnauthorized();
      return;
    }
    const data = await res.json();
    setOrders(data);
    setLoading(false);
  }, [adminKey, onUnauthorized]);

  useEffect(() => {
    load();
  }, [load]);

  async function updateStatus(id: number, status: string) {
    const res = await fetch(`/api/orders/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json", "x-admin-key": adminKey },
      body: JSON.stringify({ status }),
    });
    if (res.status === 401) {
      onUnauthorized();
      return;
    }
    load();
  }

  if (loading) return <p className="text-slate-500">Loading orders...</p>;
  if (orders.length === 0) return <p className="text-slate-500">No orders yet.</p>;

  return (
    <div className="flex flex-col gap-4">
      {orders.map((order) => (
        <div key={order.id} className="rounded-2xl border border-black/10 p-5">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="font-black">
                Order #{order.id} — {order.customerName}
              </p>
              <p className="text-sm text-slate-500">
                {order.email} • {order.phone}
              </p>
              <p className="text-sm text-slate-500">
                {order.address}, {order.city}
              </p>
              {order.notes && (
                <p className="mt-1 text-sm italic text-slate-400">
                  Note: {order.notes}
                </p>
              )}
            </div>
            <div className="flex flex-col items-end gap-2">
              <p className="text-lg font-black">{formatPrice(order.total)}</p>
              <select
                value={order.status}
                onChange={(e) => updateStatus(order.id, e.target.value)}
                className="rounded-full border border-black/15 px-3 py-1.5 text-xs font-bold uppercase"
              >
                <option value="pending">Pending</option>
                <option value="processing">Processing</option>
                <option value="shipped">Shipped</option>
                <option value="delivered">Delivered</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>
          <ul className="mt-3 flex flex-col gap-1 border-t border-black/5 pt-3 text-sm text-slate-600">
            {order.items.map((item, idx) => (
              <li key={idx}>
                {item.quantity}× {item.name} (Size {item.size}) —{" "}
                {formatPrice(Number(item.price) * item.quantity)}
              </li>
            ))}
          </ul>
          <p className="mt-2 text-xs text-slate-400">
            Placed {new Date(order.createdAt).toLocaleString()}
          </p>
        </div>
      ))}
    </div>
  );
}

function MessagesAdmin({
  adminKey,
  onUnauthorized,
}: {
  adminKey: string;
  onUnauthorized: () => void;
}) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const res = await fetch("/api/contact", { headers: { "x-admin-key": adminKey } });
      if (res.status === 401) {
        onUnauthorized();
        return;
      }
      const data = await res.json();
      setMessages(data);
      setLoading(false);
    }
    load();
  }, [adminKey, onUnauthorized]);

  if (loading) return <p className="text-slate-500">Loading messages...</p>;
  if (messages.length === 0) return <p className="text-slate-500">No messages yet.</p>;

  return (
    <div className="flex flex-col gap-4">
      {messages.map((m) => (
        <div key={m.id} className="rounded-2xl border border-black/10 p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="font-black">
              {m.name} <span className="font-normal text-slate-400">— {m.email}</span>
            </p>
            <p className="text-xs text-slate-400">
              {new Date(m.createdAt).toLocaleString()}
            </p>
          </div>
          {m.subject && <p className="mt-1 text-sm font-semibold">{m.subject}</p>}
          <p className="mt-2 text-sm text-slate-600">{m.message}</p>
        </div>
      ))}
    </div>
  );
}
