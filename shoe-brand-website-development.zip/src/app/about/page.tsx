import Image from "next/image";
import Link from "next/link";

export default function AboutPage() {
  return (
    <main>
      <section className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
        <div className="grid items-center gap-10 md:grid-cols-2">
          <div>
            <p className="text-xs font-black uppercase tracking-widest text-orange-500">
              Our Story
            </p>
            <h1 className="mt-2 text-3xl font-black uppercase tracking-tight sm:text-4xl">
              Built by hustlers, worn by everyone.
            </h1>
            <p className="mt-5 text-slate-600">
              Let&apos;s Wear started with a simple idea: shoes should keep up
              with your grind, not slow it down. What began as a small
              sneaker studio has grown into a brand trusted by runners,
              ballers, and everyday movers who refuse to compromise on
              comfort or style.
            </p>
            <p className="mt-4 text-slate-600">
              Every pair we design goes through rigorous testing on real
              streets, courts, and trails. We work directly with factories we
              trust, cutting out the markup so you get premium quality
              without the premium price tag.
            </p>
            <Link
              href="/products"
              className="mt-6 inline-block rounded-full bg-black px-7 py-3 text-sm font-black uppercase tracking-wide text-white transition hover:bg-orange-500"
            >
              Shop Our Collection
            </Link>
          </div>
          <div className="relative aspect-[4/3] overflow-hidden rounded-3xl">
            <Image
              src="/images/about-workshop.jpg"
              alt="Let's Wear shoemaking workshop"
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 560px"
            />
          </div>
        </div>
      </section>

      <section className="bg-slate-950 py-16 text-white">
        <div className="mx-auto grid max-w-7xl gap-8 px-5 text-center sm:px-8 md:grid-cols-4">
          {[
            { stat: "150K+", label: "Pairs Sold" },
            { stat: "40+", label: "Countries Shipped" },
            { stat: "4.8/5", label: "Average Rating" },
            { stat: "24/7", label: "Customer Support" },
          ].map((item) => (
            <div key={item.label}>
              <p className="text-3xl font-black text-orange-500 sm:text-4xl">
                {item.stat}
              </p>
              <p className="mt-2 text-sm uppercase tracking-wide text-white/60">
                {item.label}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
        <h2 className="text-center text-2xl font-black uppercase tracking-tight sm:text-3xl">
          What we stand for
        </h2>
        <div className="mt-10 grid gap-8 md:grid-cols-3">
          {[
            {
              icon: "🧵",
              title: "Quality Craftsmanship",
              desc: "Premium materials and durable construction in every stitch.",
            },
            {
              icon: "🌍",
              title: "Sustainable Sourcing",
              desc: "Responsibly sourced materials and ethical manufacturing partners.",
            },
            {
              icon: "❤️",
              title: "Community First",
              desc: "A portion of every sale supports grassroots youth sports programs.",
            },
          ].map((item) => (
            <div
              key={item.title}
              className="rounded-2xl border border-black/10 p-8 text-center"
            >
              <div className="text-4xl">{item.icon}</div>
              <h3 className="mt-4 text-lg font-black uppercase">{item.title}</h3>
              <p className="mt-2 text-sm text-slate-600">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
