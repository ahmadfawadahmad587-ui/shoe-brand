"use client";

import Image from "next/image";
import Link from "next/link";
import { useCart } from "@/lib/cart-context";
import { formatPrice } from "@/lib/format";

export default function CartPage() {
  const { items, removeItem, updateQuantity, totalPrice } = useCart();

  if (items.length === 0) {
    return (
      <main className="mx-auto flex max-w-3xl flex-col items-center gap-4 px-5 py-24 text-center">
        <p className="text-6xl">👟</p>
        <h1 className="text-2xl font-black uppercase">Your bag is empty</h1>
        <p className="text-slate-500">
          Looks like you haven&apos;t added any shoes yet.
        </p>
        <Link
          href="/products"
          className="mt-3 rounded-full bg-black px-7 py-3 text-sm font-black uppercase tracking-wide text-white transition hover:bg-orange-500"
        >
          Start Shopping
        </Link>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-5xl px-5 py-10 sm:px-8">
      <h1 className="text-3xl font-black uppercase tracking-tight">Your Bag</h1>

      <div className="mt-8 grid gap-10 md:grid-cols-3">
        <ul className="flex flex-col gap-5 md:col-span-2">
          {items.map((item) => (
            <li
              key={`${item.productId}-${item.size}`}
              className="flex gap-4 rounded-2xl border border-black/10 p-4"
            >
              <div className="relative h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-slate-100">
                <Image
                  src={item.imageUrl}
                  alt={item.name}
                  fill
                  className="object-cover"
                  sizes="96px"
                />
              </div>
              <div className="flex flex-1 flex-col justify-between">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <Link
                      href={`/products/${item.slug}`}
                      className="font-black hover:text-orange-500"
                    >
                      {item.name}
                    </Link>
                    <p className="text-sm text-slate-500">Size: {item.size}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeItem(item.productId, item.size)}
                    className="text-xs font-bold text-slate-400 hover:text-red-500"
                  >
                    Remove
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center rounded-full border border-black/15">
                    <button
                      type="button"
                      onClick={() =>
                        updateQuantity(item.productId, item.size, item.quantity - 1)
                      }
                      className="px-3 py-1.5 font-bold disabled:opacity-30"
                      disabled={item.quantity <= 1}
                    >
                      −
                    </button>
                    <span className="px-3 text-sm font-bold">{item.quantity}</span>
                    <button
                      type="button"
                      onClick={() =>
                        updateQuantity(item.productId, item.size, item.quantity + 1)
                      }
                      className="px-3 py-1.5 font-bold disabled:opacity-30"
                      disabled={item.quantity >= item.stock}
                    >
                      +
                    </button>
                  </div>
                  <p className="font-black">
                    {formatPrice(Number(item.price) * item.quantity)}
                  </p>
                </div>
              </div>
            </li>
          ))}
        </ul>

        <div className="h-fit rounded-2xl border border-black/10 p-6">
          <h2 className="text-lg font-black uppercase">Order Summary</h2>
          <div className="mt-4 flex justify-between text-sm text-slate-600">
            <span>Subtotal</span>
            <span>{formatPrice(totalPrice)}</span>
          </div>
          <div className="mt-2 flex justify-between text-sm text-slate-600">
            <span>Shipping</span>
            <span>{totalPrice >= 75 ? "Free" : formatPrice(9.99)}</span>
          </div>
          <div className="mt-4 flex justify-between border-t border-black/10 pt-4 text-base font-black">
            <span>Total</span>
            <span>
              {formatPrice(totalPrice >= 75 || totalPrice === 0 ? totalPrice : totalPrice + 9.99)}
            </span>
          </div>
          <Link
            href="/checkout"
            className="mt-6 block w-full rounded-full bg-orange-500 px-5 py-3 text-center text-sm font-black uppercase tracking-wide text-white transition hover:bg-orange-600"
          >
            Proceed to Checkout
          </Link>
          <Link
            href="/products"
            className="mt-3 block w-full rounded-full border border-black/10 px-5 py-3 text-center text-sm font-bold uppercase tracking-wide text-black transition hover:bg-slate-100"
          >
            Continue Shopping
          </Link>
        </div>
      </div>
    </main>
  );
}
