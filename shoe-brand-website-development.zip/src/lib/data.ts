import { db } from "@/db";
import { products } from "@/db/schema";
import { desc, eq, ne, and } from "drizzle-orm";
import type { Product } from "@/lib/types";

function serialize(row: typeof products.$inferSelect): Product {
  return {
    id: row.id,
    name: row.name,
    slug: row.slug,
    description: row.description,
    price: row.price,
    compareAtPrice: row.compareAtPrice,
    category: row.category,
    imageUrl: row.imageUrl,
    sizes: row.sizes ?? [],
    colors: row.colors ?? [],
    stock: row.stock,
    featured: row.featured,
    isNew: row.isNew,
    createdAt: row.createdAt.toISOString(),
  };
}

export async function getAllProducts(category?: string): Promise<Product[]> {
  const rows = category && category !== "all"
    ? await db.select().from(products).where(eq(products.category, category)).orderBy(desc(products.createdAt))
    : await db.select().from(products).orderBy(desc(products.createdAt));
  return rows.map(serialize);
}

export async function getFeaturedProducts(): Promise<Product[]> {
  const rows = await db
    .select()
    .from(products)
    .where(eq(products.featured, true))
    .orderBy(desc(products.createdAt));
  return rows.map(serialize);
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const rows = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  if (rows.length === 0) return null;
  return serialize(rows[0]);
}

export async function getRelatedProducts(category: string, excludeSlug: string): Promise<Product[]> {
  const rows = await db
    .select()
    .from(products)
    .where(and(eq(products.category, category), ne(products.slug, excludeSlug)))
    .limit(4);
  return rows.map(serialize);
}

export async function getCategories(): Promise<string[]> {
  const rows = await db.select({ category: products.category }).from(products);
  return Array.from(new Set(rows.map((r) => r.category)));
}
