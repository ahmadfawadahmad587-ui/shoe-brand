export type Product = {
  id: number;
  name: string;
  slug: string;
  description: string;
  price: string;
  compareAtPrice: string | null;
  category: string;
  imageUrl: string;
  sizes: string[];
  colors: string[];
  stock: number;
  featured: boolean;
  isNew: boolean;
  createdAt: string;
};

export type CartItem = {
  productId: number;
  name: string;
  slug: string;
  imageUrl: string;
  size: string;
  price: string;
  quantity: number;
  stock: number;
};
