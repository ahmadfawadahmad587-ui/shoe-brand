export function formatPrice(value: string | number): string {
  const numeric = typeof value === "string" ? Number(value) : value;
  if (Number.isNaN(numeric)) return "$0.00";
  return `$${numeric.toFixed(2)}`;
}
