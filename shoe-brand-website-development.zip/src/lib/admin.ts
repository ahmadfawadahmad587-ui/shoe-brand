import { NextRequest } from "next/server";

export const ADMIN_KEY = process.env.ADMIN_SECRET_KEY || "letswear-admin-2024";

export function isAdminRequest(req: NextRequest): boolean {
  const header = req.headers.get("x-admin-key");
  return header === ADMIN_KEY;
}
