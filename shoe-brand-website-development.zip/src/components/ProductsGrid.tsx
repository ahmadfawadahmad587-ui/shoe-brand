"use client";

import { useMemo, useState } from "react";
import ProductCard from "@/components/ProductCard";
import type { Product } from "@/lib/types";

export default function ProductsGrid({
  products,
  categories,
  initialCategory,
}: {
  products: Product[];
  categories: string[];
  initialCategory: string;
}) {
  const [category, setCategory] = useState(initialCategory || "all");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("newest");

  const filtered = useMemo(() => {
    let list = [...products];
    if (category !== "all") {
      list = list.filter((p) => p.category === category);
    }
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q),
      );
    }
    if (sort === "price-asc") {
      list.sort((a, b) => Number(a.price) - Number(b.price));
    } else if (sort === "price-desc") {
      list.sort((a, b) => Number(b.price) - Number(a.price));
    } else {
      list.sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      );
    }
    return list;
  }, [products, category, search, sort]);

  return (
    <div>
      <div className="flex flex-col gap-4 border-b border-black/10 pb-6 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setCategory("all")}
            className={`rounded-full px-4 py-2 text-xs font-black uppercase tracking-wide transition ${
              category === "all"
                ? "bg-black text-white"
                : "border border-black/10 text-slate-600 hover:border-black"
            }`}
          >
            All
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setCategory(cat)}
              className={`rounded-full px-4 py-2 text-xs font-black uppercase tracking-wide transition ${
                category === cat
                  ? "bg-black text-white"
                  : "border border-black/10 text-slate-600 hover:border-black"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex gap-3">
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search shoes..."
            className="w-48 rounded-full border border-black/10 px-4 py-2 text-sm outline-none focus:border-orange-500"
          />
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="rounded-full border border-black/10 px-4 py-2 text-sm outline-none focus:border-orange-500"
          >
            <option value="newest">Newest</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
          </select>
        </div>
      </div>

      <p className="py-4 text-sm text-slate-500">
        {filtered.length} {filtered.length === 1 ? "shoe" : "shoes"} found
      </p>

      {filtered.length === 0 ? (
        <div className="py-20 text-center text-slate-500">
          <p className="text-5xl">🔍</p>
          <p className="mt-4 font-semibold">No shoes match your search.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:gap-6 md:grid-cols-3 lg:grid-cols-4">
          {filtered.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
}
