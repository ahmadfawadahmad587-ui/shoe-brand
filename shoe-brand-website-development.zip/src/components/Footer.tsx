"use client";

import Link from "next/link";
import { useState, type FormEvent } from "react";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">(
    "idle",
  );

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!email) return;
    setStatus("loading");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) throw new Error("failed");
      setStatus("done");
      setEmail("");
    } catch {
      setStatus("error");
    }
  }

  return (
    <footer className="border-t border-black/10 bg-black text-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 sm:px-8 md:grid-cols-4">
        <div>
          <p className="text-2xl font-black">Let&apos;s Wear</p>
          <p className="mt-3 max-w-xs text-sm text-white/60">
            Step boldly. Premium sneakers and shoes designed for movement,
            style, and everyday hustle.
          </p>
        </div>

        <div>
          <p className="text-sm font-bold uppercase tracking-wide text-white/80">
            Shop
          </p>
          <ul className="mt-4 flex flex-col gap-2 text-sm text-white/60">
            <li><Link href="/products?category=running" className="hover:text-white">Running</Link></li>
            <li><Link href="/products?category=lifestyle" className="hover:text-white">Lifestyle</Link></li>
            <li><Link href="/products?category=basketball" className="hover:text-white">Basketball</Link></li>
            <li><Link href="/products" className="hover:text-white">All Shoes</Link></li>
          </ul>
        </div>

        <div>
          <p className="text-sm font-bold uppercase tracking-wide text-white/80">
            Company
          </p>
          <ul className="mt-4 flex flex-col gap-2 text-sm text-white/60">
            <li><Link href="/about" className="hover:text-white">Our Story</Link></li>
            <li><Link href="/contact" className="hover:text-white">Contact Us</Link></li>
            <li><Link href="/admin" className="hover:text-white">Admin</Link></li>
          </ul>
        </div>

        <div>
          <p className="text-sm font-bold uppercase tracking-wide text-white/80">
            Stay in the loop
          </p>
          <p className="mt-4 text-sm text-white/60">
            Get drops, discounts, and new arrivals in your inbox.
          </p>
          <form onSubmit={handleSubmit} className="mt-3 flex gap-2">
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@email.com"
              className="w-full rounded-full border border-white/20 bg-white/5 px-4 py-2 text-sm outline-none placeholder:text-white/40 focus:border-orange-500"
            />
            <button
              type="submit"
              disabled={status === "loading"}
              className="shrink-0 rounded-full bg-orange-500 px-4 py-2 text-sm font-bold transition hover:bg-orange-600 disabled:opacity-60"
            >
              Join
            </button>
          </form>
          {status === "done" && (
            <p className="mt-2 text-xs text-green-400">
              You&apos;re subscribed! 🎉
            </p>
          )}
          {status === "error" && (
            <p className="mt-2 text-xs text-red-400">
              Something went wrong. Try again.
            </p>
          )}
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs text-white/40">
        © {new Date().getFullYear()} Let&apos;s Wear. All rights reserved.
      </div>
    </footer>
  );
}
