"use client";

import Image from "next/image";
import Link from "next/link";
import { useCart } from "@/lib/cart-context";
import { formatPrice } from "@/lib/format";

export default function CartDrawer() {
  const {
    items,
    isCartOpen,
    closeCart,
    removeItem,
    updateQuantity,
    totalPrice,
  } = useCart();

  return (
    <div
      className={`fixed inset-0 z-50 transition ${
        isCartOpen ? "pointer-events-auto" : "pointer-events-none"
      }`}
      aria-hidden={!isCartOpen}
    >
      <div
        onClick={closeCart}
        className={`absolute inset-0 bg-black/50 transition-opacity ${
          isCartOpen ? "opacity-100" : "opacity-0"
        }`}
      />
      <aside
        className={`absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-white shadow-2xl transition-transform duration-300 ${
          isCartOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between border-b border-black/10 px-6 py-5">
          <h2 className="text-lg font-black uppercase tracking-wide">
            Your Bag ({items.reduce((s, i) => s + i.quantity, 0)})
          </h2>
          <button
            type="button"
            onClick={closeCart}
            className="flex h-9 w-9 items-center justify-center rounded-full border border-black/10 hover:bg-slate-100"
            aria-label="Close cart"
          >
            ✕
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-4">
          {items.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center gap-3 text-center text-slate-500">
              <p className="text-5xl">👟</p>
              <p className="font-semibold">Your bag is empty</p>
              <Link
                href="/products"
                onClick={closeCart}
                className="mt-2 rounded-full bg-black px-5 py-2 text-sm font-bold text-white"
              >
                Start Shopping
              </Link>
            </div>
          ) : (
            <ul className="flex flex-col gap-5">
              {items.map((item) => (
                <li
                  key={`${item.productId}-${item.size}`}
                  className="flex gap-4 border-b border-black/5 pb-5"
                >
                  <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-slate-100">
                    <Image
                      src={item.imageUrl}
                      alt={item.name}
                      fill
                      className="object-cover"
                      sizes="80px"
                    />
                  </div>
                  <div className="flex flex-1 flex-col gap-1">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-sm font-bold">{item.name}</p>
                      <button
                        type="button"
                        onClick={() => removeItem(item.productId, item.size)}
                        className="text-xs font-semibold text-slate-400 hover:text-red-500"
                      >
                        Remove
                      </button>
                    </div>
                    <p className="text-xs text-slate-500">Size: {item.size}</p>
                    <div className="mt-1 flex items-center justify-between">
                      <div className="flex items-center rounded-full border border-black/10">
                        <button
                          type="button"
                          onClick={() =>
                            updateQuantity(
                              item.productId,
                              item.size,
                              item.quantity - 1,
                            )
                          }
                          className="px-2.5 py-1 text-sm font-bold disabled:opacity-30"
                          disabled={item.quantity <= 1}
                        >
                          −
                        </button>
                        <span className="px-2 text-sm font-semibold">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            updateQuantity(
                              item.productId,
                              item.size,
                              item.quantity + 1,
                            )
                          }
                          className="px-2.5 py-1 text-sm font-bold disabled:opacity-30"
                          disabled={item.quantity >= item.stock}
                        >
                          +
                        </button>
                      </div>
                      <p className="text-sm font-bold">
                        {formatPrice(Number(item.price) * item.quantity)}
                      </p>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {items.length > 0 && (
          <div className="border-t border-black/10 px-6 py-5">
            <div className="mb-4 flex items-center justify-between text-base font-bold">
              <span>Subtotal</span>
              <span>{formatPrice(totalPrice)}</span>
            </div>
            <Link
              href="/checkout"
              onClick={closeCart}
              className="block w-full rounded-full bg-orange-500 px-5 py-3 text-center text-sm font-black uppercase tracking-wide text-white transition hover:bg-orange-600"
            >
              Checkout
            </Link>
            <Link
              href="/cart"
              onClick={closeCart}
              className="mt-2 block w-full rounded-full border border-black/10 px-5 py-3 text-center text-sm font-bold uppercase tracking-wide text-black transition hover:bg-slate-100"
            >
              View Bag
            </Link>
          </div>
        )}
      </aside>
    </div>
  );
}
