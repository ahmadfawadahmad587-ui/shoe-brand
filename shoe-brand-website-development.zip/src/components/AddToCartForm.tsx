"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useCart } from "@/lib/cart-context";
import type { Product } from "@/lib/types";

export default function AddToCartForm({ product }: { product: Product }) {
  const { addItem, openCart } = useCart();
  const router = useRouter();
  const [size, setSize] = useState(product.sizes[0] ?? "");
  const [quantity, setQuantity] = useState(1);
  const [error, setError] = useState("");

  function handleAdd() {
    if (!size) {
      setError("Please select a size.");
      return;
    }
    setError("");
    addItem({
      productId: product.id,
      name: product.name,
      slug: product.slug,
      imageUrl: product.imageUrl,
      size,
      price: product.price,
      quantity,
      stock: product.stock,
    });
    openCart();
  }

  function handleBuyNow() {
    handleAdd();
    router.push("/checkout");
  }

  const soldOut = product.stock <= 0;

  return (
    <div className="mt-6 flex flex-col gap-5">
      <div>
        <p className="mb-2 text-sm font-black uppercase tracking-wide">
          Select Size
        </p>
        <div className="flex flex-wrap gap-2">
          {product.sizes.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setSize(s)}
              className={`h-11 min-w-[2.75rem] rounded-lg border px-3 text-sm font-bold transition ${
                size === s
                  ? "border-black bg-black text-white"
                  : "border-black/15 text-slate-700 hover:border-black"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-2 text-sm font-black uppercase tracking-wide">
          Quantity
        </p>
        <div className="flex w-fit items-center rounded-full border border-black/15">
          <button
            type="button"
            onClick={() => setQuantity((q) => Math.max(1, q - 1))}
            className="px-4 py-2 text-lg font-bold"
          >
            −
          </button>
          <span className="px-3 text-sm font-bold">{quantity}</span>
          <button
            type="button"
            onClick={() => setQuantity((q) => Math.min(product.stock || 1, q + 1))}
            className="px-4 py-2 text-lg font-bold"
          >
            +
          </button>
        </div>
      </div>

      {error && <p className="text-sm font-semibold text-red-500">{error}</p>}

      <div className="flex flex-col gap-3 sm:flex-row">
        <button
          type="button"
          onClick={handleAdd}
          disabled={soldOut}
          className="flex-1 rounded-full border-2 border-black px-6 py-3 text-sm font-black uppercase tracking-wide transition hover:bg-black hover:text-white disabled:cursor-not-allowed disabled:opacity-40"
        >
          {soldOut ? "Sold Out" : "Add to Bag"}
        </button>
        <button
          type="button"
          onClick={handleBuyNow}
          disabled={soldOut}
          className="flex-1 rounded-full bg-orange-500 px-6 py-3 text-sm font-black uppercase tracking-wide text-white transition hover:bg-orange-600 disabled:cursor-not-allowed disabled:opacity-40"
        >
          Buy Now
        </button>
      </div>
      {!soldOut && (
        <p className="text-xs text-slate-500">
          Only {product.stock} left in stock — order soon.
        </p>
      )}
    </div>
  );
}
