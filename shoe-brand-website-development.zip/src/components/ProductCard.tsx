"use client";

import Image from "next/image";
import Link from "next/link";
import { useCart } from "@/lib/cart-context";
import { formatPrice } from "@/lib/format";
import type { Product } from "@/lib/types";

export default function ProductCard({ product }: { product: Product }) {
  const { addItem } = useCart();
  const onSale =
    product.compareAtPrice && Number(product.compareAtPrice) > Number(product.price);

  function quickAdd() {
    if (product.stock <= 0) return;
    const defaultSize = product.sizes[0] ?? "One Size";
    addItem({
      productId: product.id,
      name: product.name,
      slug: product.slug,
      imageUrl: product.imageUrl,
      size: defaultSize,
      price: product.price,
      quantity: 1,
      stock: product.stock,
    });
  }

  return (
    <div className="group relative flex flex-col overflow-hidden rounded-2xl border border-black/5 bg-white transition hover:shadow-xl">
      <Link href={`/products/${product.slug}`} className="block">
        <div className="relative aspect-square w-full overflow-hidden bg-slate-100">
          <Image
            src={product.imageUrl}
            alt={product.name}
            fill
            className="object-cover transition duration-500 group-hover:scale-105"
            sizes="(max-width: 768px) 50vw, 25vw"
          />
          <div className="absolute left-3 top-3 flex flex-col gap-1.5">
            {product.isNew && (
              <span className="rounded-full bg-black px-2.5 py-1 text-[10px] font-black uppercase tracking-wider text-white">
                New
              </span>
            )}
            {onSale && (
              <span className="rounded-full bg-orange-500 px-2.5 py-1 text-[10px] font-black uppercase tracking-wider text-white">
                Sale
              </span>
            )}
            {product.stock <= 0 && (
              <span className="rounded-full bg-slate-700 px-2.5 py-1 text-[10px] font-black uppercase tracking-wider text-white">
                Sold Out
              </span>
            )}
          </div>
        </div>
      </Link>
      <div className="flex flex-1 flex-col gap-1 p-4">
        <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
          {product.category}
        </p>
        <Link href={`/products/${product.slug}`}>
          <h3 className="text-sm font-bold text-slate-900 hover:text-orange-500">
            {product.name}
          </h3>
        </Link>
        <div className="mt-1 flex items-center gap-2">
          <span className="text-sm font-black">{formatPrice(product.price)}</span>
          {onSale && (
            <span className="text-xs font-semibold text-slate-400 line-through">
              {formatPrice(product.compareAtPrice as string)}
            </span>
          )}
        </div>
        <button
          type="button"
          onClick={quickAdd}
          disabled={product.stock <= 0}
          className="mt-3 w-full rounded-full border border-black px-4 py-2 text-xs font-black uppercase tracking-wide transition hover:bg-black hover:text-white disabled:cursor-not-allowed disabled:opacity-40"
        >
          {product.stock <= 0 ? "Sold Out" : "Quick Add"}
        </button>
      </div>
    </div>
  );
}
